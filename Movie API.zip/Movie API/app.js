require('dotenv').config();
const express = require("express");
const request = require("request");
const https = require("https");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const mongoose = require("mongoose");

const app = express();
//Ejs Package 
app.set('view engine', 'ejs');

//Body parser
app.use(bodyParser.urlencoded({
  extended: true
}));

//use of Public folder(Like images and Css files included)
app.use(express.static("public"));

// Mongo db connection
const conn = mongoose.connect("mongodb://127.0.0.1:27017/movieDB", {
  useNewUrlParser: true,
  useUnifiedTopology: true // Fix the typo here
});

//  Movie Schema
const movieSchema = {
    title: {
      type: String,
      require: true
    },
    year: {
      type: Number,
      require: true
    }
  };

//   Schema Model 
const Movie = mongoose.model("Movie", movieSchema); // Use a more appropriate name like "Movie"

let posts = [];

  app.get("/", async (req, res) => {
    try {
      const movies = await Movie.find({});
      console.log(movies);
      res.render("index", { movies });
    } catch (error) {
      console.error(error);
      res.status(500).send("An error occurred.");
    }
  });

//   app.post("/submit", async (req, res) => {
//     try {
//       const post = new Movie({
//         title: req.body.title,
//         year: req.body.year
//       });
  
//       await post.save();
//       console.log("Movie saved successfully");
//       res.redirect("/");
//     } catch (error) {
//       console.error("Error saving movie:", error);
//       res.status(500).send("An error occurred.");
//     }
//   });

  
//   app.post("/submit", function(req, res) {
//     const url = "http://www.omdbapi.com/?i=tt3896198&apikey=c3b2c14d";
//     const data = {
     
//   }
//   const jsonData = JSON.stringify(data);
  
//     const options = {
//       method: "POST",
//       auth: "key:c3b2c14d"
//   }
//   console.log(options)
//     https.request(url, options, function(response) {
//            response.on("data", function(data) {
//               console.log(JSON.parse(data));
//               if(response.statusCode === 200) {
//                   res.render("success.html")
//               } else {
//                   res.render("failure.html")
//               }
//            })
//     })
//     req.send(jsonData);
//     req.end();
    
//   });
app.post("/submit", function (req, res) {
    const url = "https://www.omdbapi.com/?i=tt3896198&apikey=c3b2c14d";
    const data = {
      // Add your request data here if needed
    };
    const jsonData = JSON.stringify(data);
  
    const options = {
      method: "POST",
      auth: "key:c3b2c14d"
    };
  
    const externalRequest = https.request(url, options, function (externalResponse) {
      let responseData = "";
  
      externalResponse.on("data", function (chunk) {
        responseData += chunk;
      });
  
      externalResponse.on("end", function () {
        const responseJson = JSON.parse(responseData);
  
        if (externalResponse.statusCode === 200) {
          // Successful response from external API
          // You can use responseJson for further processing
          console.log(responseJson);
          res.render("success.html");
        } else {
          // Error response from external API
          console.error("Error from external API:", responseJson);
          res.render("failure.html");
        }
      });
    });
  
    externalRequest.on("error", function (error) {
      console.error("Error making external API request:", error);
      res.status(500).send("An error occurred while making the external API request.");
    });
  
    // Send the JSON data as the request body
    externalRequest.write(jsonData);
    externalRequest.end();
  });
  

app.listen(process.env.PORT || 3000, function () {
  console.log("Your server is running on port 3000");
});
